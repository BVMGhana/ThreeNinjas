<?php echo e($slot); ?>

<?php /**PATH C:\Users\joshu\source\three_ninjas_composer_vue\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/subcopy.blade.php ENDPATH**/ ?>